# Kokpit Okulları - Technical Handoff Documentation

This document serves as an end-to-end technical handoff and architectural summary of the "Kokpit Okulları Yesevi Kampüsü" website project. It is designed to get the new Project Manager (ChatGPT) fully up to speed with the current state, design language, and technical architecture of the application.

## 1. Project Overview & Tech Stack
- **Project Name:** Kokpit Okulları Yesevi Kampüsü Kurumsal Web Sitesi
- **Framework:** React 18+ bootstrapped with Vite (`create-vite` react template).
- **Routing:** `react-router-dom` (Client-side SPA routing, easily exportable to static HTML).
- **Styling:** Pure/Vanilla CSS with heavily customized CSS Modules and Global variables. No Tailwind.
- **Icons:** `lucide-react` (Feather-based SVG icons).
- **Deployment Strategy:** Static Site Generation (SSG) / Single Page App (SPA). The build output (`dist/`) can be hosted on any static file server, cPanel, or Vercel/Netlify.

## 2. Design System & UI Architecture
The UI is built strictly around a **"Premium Dark Mode & Glassmorphism"** theme requested by the client, aiming for a modern, sleek, and high-end tech-campus aesthetic.

### Typography
- **Primary Font:** `Plus Jakarta Sans` (Loaded via Google Fonts in `index.css`).

### Color Palette (Defined in `index.css`)
```css
:root {
  --color-primary: #0B192C; /* Deep Navy Backgrounds */
  --color-primary-light: #1E3E62;
  --color-secondary: #FF204E; /* Vibrant Glowing Red for Actions */
  --color-secondary-hover: #D01135;
  --color-bg: #07101A; /* Very Dark Navy Base */
  --color-text: #F8FAFC;
  --color-text-light: #94A3B8;
  --color-white: #FFFFFF;
}
```

### Glassmorphism Tokens
We use custom CSS tokens for glass effects applied to the header, cards, and dropdowns:
- `background: rgba(255, 255, 255, 0.15)`
- `backdrop-filter: blur(25px)`
- Subtle inset shadows and white translucent borders (`rgba(255, 255, 255, 0.3)`) to simulate physical glass edges.

### Buttons & Glow Effects
The primary CTA button (`.btn-glow-red`) uses a linear gradient background (`#ff1a40` to `#ff4d6d`) combined with an aggressive glowing box-shadow (`box-shadow: 0 0 50px 15px rgba(255, 51, 85, 0.8)`) to create a "neon" effect against the dark background.

## 3. Application Structure

```text
src/
├── assets/             # Static assets (SVGs, etc.)
├── components/         # Reusable UI components
│   ├── Header.jsx      # Top navigation (Glass pill design)
│   ├── Header.css
│   ├── Footer.jsx      # Multi-column footer
│   └── Footer.css
├── layouts/            # Page layouts
│   └── MainLayout.jsx  # Wraps Header, <Outlet />, Footer, and WhatsApp FAB
├── pages/              # Route components
│   ├── HomePage.jsx    # Hero, School Cards, Announcements
│   ├── HomePage.css
│   ├── AboutPage.jsx   # Hakkımızda, Misyon, Vizyon
│   ├── AboutPage.css
│   ├── ContactPage.jsx # İletişim, Bize Sorun Formu
│   ├── ContactPage.css
│   ├── HealthHighSchool.jsx # Sağlık Meslek Lisesi detayları
│   ├── AviationHighSchool.jsx # Havacılık Lisesi detayları
│   ├── SoftwareCollege.jsx # Matrix Yazılım Koleji detayları
│   ├── Schools.css     # Shared CSS for school detail pages
│   └── PlaceholderPage.jsx # Dynamic component for empty/future routes
├── App.jsx             # React Router configuration
├── index.css           # Global CSS, Design System, CSS Variables
└── main.jsx            # Entry point
```

## 4. Routing Map (`App.jsx`)
The application uses `<BrowserRouter>`. All routes are wrapped inside `<MainLayout />`.

### Static Content Routes (Completed)
- `/` -> `HomePage`
- `/hakkimizda` -> `AboutPage`
- `/iletisim` -> `ContactPage`
- `/saglik-meslek-lisesi` -> `HealthHighSchool` (Also mapped to `/bolum/2/...` etc. for legacy URL support)
- `/havacilik-lisesi` -> `AviationHighSchool`
- `/matrix-yazilim-koleji` -> `SoftwareCollege`

### Dynamic / Future Routes (PlaceholderPage)
The following routes currently render `PlaceholderPage` because the original document stated these will be managed via a dynamic CMS in the future:
- `/insan-kaynaklari`
- `/egitim-kadromuz`
- `/hedeflerimiz`
- `/egitim`
- `/okullarimiz`, `/bolumlerimiz`, `/onur-tablomuz`, `/basin`, `/ziyaretci-defteri`
- `/foto-galeriler`, `/video-galeri`
- `/kvkk-ve-aydinlatma-metni`

## 5. Component Highlights

### `Header.jsx`
- Designed as a floating "pill" attached to the top of the viewport (`top: 0`, `border-radius: 0 0 24px 24px`).
- Features a complex desktop navigation matching the exact nested structure provided by the client (Kurumsal Dropdown, Galeri Dropdown, etc.).
- Implements custom pure CSS dropdowns (`.dropdown:hover .dropdown-menu`).

### `HomePage.jsx`
- **Hero Section:** Uses a dark campus background image from Unsplash with a deep navy gradient overlay (`linear-gradient(to bottom, rgba(10, 20, 35, 0.2) 0%, rgba(10, 20, 35, 0.5) 100%)`).
- **School Cards:** Three main branches (Health, Aviation, Software) represented as glass cards with hover lift animations and color-coded icon backgrounds.

### `MainLayout.jsx`
- Injects a global Floating Action Button (FAB) for WhatsApp (`.floating-whatsapp`) fixed at the bottom right corner, linking directly to the institution's official WA line (`wa.me/905305801525`).

## 6. SEO & Meta Information
- Handled in `index.html`.
- **Title:** Eskişehir Kokpit Okulları | Havacılık Lisesi - Sağlık Lisesi
- **Meta Description:** Included exactly as requested in the source documentation.

## 7. Next Steps for the Project Manager (ChatGPT)
To continue development, the new PM should focus on:
1. **CMS/Backend Integration:** Decide on the backend architecture (e.g., Headless CMS like Strapi, Firebase, or a custom Node.js backend) to feed data into the `PlaceholderPage` routes (Announcements, Gallery, Staff).
2. **Form Handling:** Wire up the "Bize Sorun" form in `ContactPage.jsx` to an email service (like EmailJS) or an API endpoint.
3. **Authentication:** The client mentioned future plans for Student/Parent login portals. The React Router setup is ready for Private Routes to be added.
4. **Media Replacement:** Replace the Unsplash placeholder background in `HomePage.css` (`.hero-section`) with high-resolution actual campus photos provided by the client.

## 8. Development Commands
- Start dev server: `npm run dev`
- Build for production: `npm run build`
- Preview production build: `npm run preview`
