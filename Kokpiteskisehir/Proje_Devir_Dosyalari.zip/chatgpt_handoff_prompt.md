# PROJE DEVİR DÖKÜMANI (ChatGPT'ye Gönderilecek İstem/Prompt)

Merhaba ChatGPT, ben bu projenin yöneticisiyim. Kokpit Okulları için hazırladığımız kurumsal web sitesi projesinin başlangıç altyapısını Antigravity AI ile tamamladık. Yola seninle devam edeceğiz. Aşağıda projenin mevcut durumunu, kod yapılarını ve biten sayfaları iletiyorum. Lütfen bu yapıyı analiz et ve bundan sonraki geliştirmeler için hazır ol.

*(Not: Bu mesajla birlikte projenin mevcut durumunu gösteren ekran görüntülerini de sana ekte iletiyorum.)*

---

## 1. MEVCUT DURUM VE STAGING LİNKİ
- **Staging / Canlı Ortam:** Proje şu an public bir sunucuda (Vercel/Netlify) yayında değil. Geliştirme ortamında, lokalde `http://localhost:5173/` portunda çalışıyor. *(Ekli ekran görüntüleri bu lokal sunucudan alınmıştır.)*
- **Teknoloji:** Vite + React (JavaScript), `react-router-dom` ile SPA yapısı, Tailwind OLMADAN Vanilla CSS (Glassmorphism & Koyu Tema).

## 2. TAMAMLANAN SAYFALAR
Aşağıdaki sayfalar, bize iletilen içerik dökümantasyonundaki orijinal metinlere sadık kalınarak, tasarımları ve CSS kodlarıyla birlikte tamamen bitirilmiştir:

1. **Ana Sayfa (`/`)**: Hero section, glassmorphism kartlar, duyurular, "Tanıtım Videoları" ve "Bursluluk Sınavı" butonları.
2. **Hakkımızda (`/hakkimizda`)**: Amacımız, Vizyonumuz, Misyonumuz, Hedeflerimiz.
3. **İletişim (`/iletisim`)**: İletişim bilgileri (Şeker Mh. adresi), KVKK onaylı "Bize Sorun" formu.
4. **Sağlık Meslek Lisesi (`/saglik-meslek-lisesi`)**: Hemşire Yardımcılığı, Ebe Yardımcılığı, Sağlık Bakım Teknisyenliği içerikleri.
5. **Havacılık Lisesi (`/havacilik-lisesi`)**: Pilotaj, İHA, Kabin Memurluğu programları ve okul dersleri.
6. **Matrix Yazılım Koleji (`/matrix-yazilim-koleji`)**: Web geliştirme, oyun geliştirme, veritabanı müfredat detayları.
7. **Placeholder Sayfası (Dinamik İçerikler İçin)**: İnsan Kaynakları, Eğitim Kadrosu, Galeri, Basın gibi ileride bir CMS (Yönetim Paneli) ile beslenecek sayfalar için tasarlanan geçici bileşen.

## 3. WORKSPACE VE KLASÖR YAPISI
Proje kök dizini (Antigravity Workspace: `C:\Users\user\Desktop\Kokpit okulları`) altındaki yapı şu şekildedir:

```text
src/
├── assets/
├── components/
│   ├── Header.jsx (Açılır menüler ve glassmorphism nav-bar)
│   ├── Header.css
│   ├── Footer.jsx
│   └── Footer.css
├── layouts/
│   └── MainLayout.jsx (Header, Outlet, Footer ve WhatsApp Floating Butonunu kapsar)
├── pages/
│   ├── HomePage.jsx & HomePage.css
│   ├── AboutPage.jsx & AboutPage.css
│   ├── ContactPage.jsx & ContactPage.css
│   ├── HealthHighSchool.jsx
│   ├── AviationHighSchool.jsx
│   ├── SoftwareCollege.jsx
│   ├── Schools.css (Liseler için ortak stil dosyası)
│   └── PlaceholderPage.jsx
├── App.jsx (React Router yapılandırması)
├── index.css (Global CSS, renk değişkenleri, WhatsApp buton stili)
└── main.jsx
```

## 4. TEMEL COMPONENT ÇIKTILARI (Örnek Kodlar)

**Global Temel Renkler (`index.css`):**
```css
:root {
  --color-primary: #0B192C; 
  --color-secondary: #FF204E; /* Kırmızı Glow Efekti İçin */
  --color-bg: #07101A;
}
```

**App.jsx (Router Yapısı):**
```javascript
import { Routes, Route } from 'react-router-dom'
import MainLayout from './layouts/MainLayout'
import HomePage from './pages/HomePage'
/* ...diğer importlar... */

function App() {
  return (
    <Routes>
      <Route path="/" element={<MainLayout />}>
        <Route index element={<HomePage />} />
        <Route path="hakkimizda" element={<AboutPage />} />
        <Route path="saglik-meslek-lisesi" element={<HealthHighSchool />} />
        <Route path="havacilik-lisesi" element={<AviationHighSchool />} />
        <Route path="matrix-yazilim-koleji" element={<SoftwareCollege />} />
        <Route path="iletisim" element={<ContactPage />} />
        {/* CMS bekleyen dinamik sayfalar PlaceholderPage'e yönlendirildi */}
        <Route path="insan-kaynaklari" element={<PlaceholderPage title="İnsan Kaynakları" />} />
      </Route>
    </Routes>
  )
}
export default App
```

**MainLayout.jsx (Kapsayıcı ve WhatsApp Butonu):**
```javascript
import { Outlet } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const MainLayout = () => {
  return (
    <div className="app-container">
      <Header />
      <main className="main-content">
        <Outlet />
      </main>
      <Footer />
      {/* Floating WhatsApp Button */}
      <a href="https://wa.me/905305801525" target="_blank" rel="noreferrer" className="floating-whatsapp">
        <img src="..." alt="WhatsApp" width="35" height="35" />
      </a>
    </div>
  );
};
export default MainLayout;
```

---
*ChatGPT'ye Not: Projenin UI/UX mimarisi "Koyu Tema" (Dark Navy) ve "Glassmorphism" (Cam efekti) üzerine kuruludur. İlerleyen geliştirmelerde ve eklenecek yeni componentlerde bu CSS yapısına ve mevcut CSS değişkenlerine (`var(--color-secondary)` gibi) sadık kalınması kritik önem taşımaktadır.*
